# 10-Minute Script Writer Prompt

Write a 10-minute YouTube script for **The Last 60 Seconds**.

## Structure

```text
00:00–00:20 — Cold Open
00:20–01:10 — What We’re Watching
01:10–02:30 — The Setup
02:30–04:30 — First Escalation
04:30–06:30 — Key Footage Breakdown
06:30–07:45 — Turning Point
07:45–08:45 — Aftermath
08:45–09:00 — Transition
09:00–10:00 — THE LAST 60 SECONDS
```

## Style

- serious
- direct
- cinematic
- no filler
- no unsupported claims
- no cheesy narrator lines
- no “in today’s video”
- no early like/subscribe call

## Required recurring line

At 08:45–09:00, use:

“Now we go to The Last 60 Seconds.”

## Final 60 seconds

Must include:

- what happened
- what changed
- what viewers missed
- why it matters

Format the script with timestamps and visual cues.
