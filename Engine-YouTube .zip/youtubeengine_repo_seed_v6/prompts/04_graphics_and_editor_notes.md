# Graphics and Editor Notes Prompt

Create timestamped graphics and editing instructions for a 10-minute episode.

Format:

```text
[00:00–00:04]
Graphic:
Text:
Editor instruction:
Purpose:
```

Use only clean, serious visual language.

Required recurring graphics:

- CASE FILE
- PUBLIC RECORD SOURCE
- WATCH CLOSELY
- LISTEN TO THIS
- WHAT CHANGED?
- THE LAST 60 SECONDS
- countdown from 60 to 0

Editor notes must include:

- zooms
- freeze frames
- replays
- blur moments
- mute moments
- audio boosts
- caption emphasis
- footage cut points
- final recap countdown instructions
