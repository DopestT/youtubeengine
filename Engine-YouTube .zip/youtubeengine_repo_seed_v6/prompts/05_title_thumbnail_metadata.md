# Title, Thumbnail, and Metadata Prompt

Generate a complete YouTube packaging set.

## Titles

Generate 25 titles:

- 10 mystery titles
- 5 bodycam titles
- 5 emotional titles
- 5 direct factual titles

Rules:
- clickable but not fake
- no unsupported guilt claims
- no private person names unless already public and safe
- no exaggerated words unless justified

## Thumbnails

Generate 10 thumbnail concepts.

Each concept must include:

- thumbnail text, max 4 words
- visual frame suggestion
- emotion target
- arrow/circle suggestion only if useful
- why it should get clicks

Style:
dark, serious, bodycam/documentary, red REC marker, not cheap.

## Metadata

Generate:

- final recommended title
- alternate title
- YouTube description
- source citation section
- disclaimer if needed
- tags
- hashtags
- pinned comment
- Shorts titles
- TikTok caption
- Instagram caption
