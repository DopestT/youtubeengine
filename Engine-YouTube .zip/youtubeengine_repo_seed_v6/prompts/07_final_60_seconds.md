# The Last 60 Seconds Segment Prompt

Write the final branded 60-second recap for the episode.

Rules:

- exactly 60 seconds in narration pacing
- intense but calm
- no new unsupported facts
- summarize the core story
- identify the key moment
- identify what viewers may have missed
- end with a clean closing line

Template:

```text
THE LAST 60 SECONDS

In the final minute, three things mattered.

One — [key detail].
Two — [key decision or statement].
Three — [what changed the outcome].

That is why this footage matters.
```

Alternate closing lines:

- “Every case comes down to the final minute.”
- “That was The Last 60 Seconds.”
- “The footage does not answer everything, but it shows the moment everything changed.”
