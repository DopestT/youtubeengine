#!/usr/bin/env bash
set -e

# Usage:
# 1. Unzip this package.
# 2. cd youtubeengine_repo_seed
# 3. Run:
#    git init
#    git branch -M main
#    git add .
#    git commit -m "Initialize The Last 60 Seconds YouTube engine"
#    git remote add origin https://github.com/DopestT/youtubeengine.git
#    git push -u origin main

echo "Run the commands in this file manually from the repo seed folder."
