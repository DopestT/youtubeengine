# Competitor Benchmark List

This file tracks channels to study for packaging, retention, thumbnails, pacing, and repeatable mechanics.

## Primary inspiration set

### Dr. Insanity
- Role: Long-form crime/story channel benchmark.
- Study areas: title patterns, long runtime packaging, thumbnail clarity, dark visual identity, suspense pacing, playlist structure, episode arcs.
- Do not copy: brand, logo, thumbnails, script phrasing, narration style, specific edits, or copyrighted media.

### M7 Crime Storytime
- Channel URL: https://youtube.com/@m7crimestorytime?si=YDopYn_wCXzcHZYB
- Role: Crime-story competitor/reference channel.
- Study areas: story selection, title hooks, thumbnail framing, cadence, use of emotional stakes, episode length, posting rhythm, Shorts vs long-form balance.
- Required data to collect manually or via YouTube Data API:
  - channel description
  - subscriber count
  - top 20 videos by views
  - latest 20 videos
  - title, runtime, view count, age, thumbnail screenshot, description, pinned comment if visible
  - opening 30 seconds transcript for at least 5 top videos
  - ending structure for at least 5 top videos
- Do not copy: specific cases, thumbnails, visual layout, exact titles, narration, or branding.

## Competitor extraction checklist

For each channel, collect:

```text
Channel name:
Channel URL:
Subscriber count:
Total videos:
Top videos:
Average successful runtime:
Common title pattern:
Common thumbnail pattern:
Common opening hook:
Common emotional trigger:
Retention devices:
CTA style:
What to copy structurally:
What to avoid copying directly:
How The Last 60 Seconds will differentiate:
```

## Differentiation rule

The Last 60 Seconds must win by owning a repeatable signature segment:

> Every episode ends with a clean final 60-second recap.

This makes the channel format easier to remember than a generic crime narration channel.
