# Weekly Improvement Loop

## What to measure

Every Sunday, collect:

- impressions
- CTR
- average view duration
- average percentage viewed
- retention curve screenshots
- top traffic source
- subscriber gain/loss
- comments
- most replayed moments
- top Shorts by views
- top titles
- top thumbnails

## Decisions to make

### If CTR is low

Fix:
- titles
- thumbnails
- first frame
- topic selection

### If retention drops in first 30 seconds

Fix:
- cold open
- remove intro
- start closer to the incident
- cut setup down

### If retention drops in middle

Fix:
- add stronger chapter transitions
- use more visual callouts
- shorten narrator explanation
- add more “watch closely” moments

### If final 60 seconds has high retention

Make it bigger:
- stronger countdown
- cleaner recap
- pinned comment asking viewers what they missed

### If comments ask the same question

Add that question to future scripts.

## Weekly prompt update

At the end of each week, update:

- title rules
- thumbnail rules
- pacing rules
- source scoring weights
- banned filler patterns
