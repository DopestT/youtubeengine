# First 10 Episode Launch Checklist

## Goal

Produce the first 10 episodes before overbuilding.

## Episode sourcing targets

Collect at least 25 candidate stories so the engine can reject weak ones.

Use this mix:

1. 8 official police critical incident releases
2. 5 public-record/bodycam traffic stops
3. 5 missing-person or family-discovery cases with official source material
4. 4 court/public-record cases with available video/audio
5. 3 odd-but-serious police interaction stories

## Intake checklist per candidate

- [ ] Raw footage or official video link saved
- [ ] Source URL saved
- [ ] Agency/source name saved
- [ ] Date/location saved if available
- [ ] Case notes added
- [ ] Any known outcome added
- [ ] Privacy risks noted
- [ ] Possible title angle noted

## Production checklist

For each candidate:

- [ ] Run intake/scoring
- [ ] Reject RED clips
- [ ] Separate SHORTS ONLY clips
- [ ] Select top 10 GREEN/YELLOW episodes
- [ ] Generate scripts
- [ ] Generate captions
- [ ] Generate graphics notes
- [ ] Generate thumbnails
- [ ] Human review risks
- [ ] Edit
- [ ] Upload unlisted first
- [ ] Final check
- [ ] Publish

## Launch schedule

Do not launch with one video.

Minimum launch package:

- 3 full 10-minute episodes
- 6 Shorts
- 1 channel trailer
- banner
- profile icon
- about section
- upload schedule

## First 10 episode cadence

```text
Week 1:
- publish 3 full episodes
- publish 6 Shorts

Week 2:
- publish 2 full episodes
- publish 4 Shorts

Week 3:
- publish 2 full episodes
- publish 4 Shorts

Week 4:
- publish 3 full episodes
- publish 6 Shorts
```

## Quality gate

Do not publish an episode unless:

- hook is strong
- title is clear
- thumbnail has one obvious idea
- script has no unsupported claims
- final 60 seconds is excellent
- all private info is blurred
