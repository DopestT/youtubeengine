# EP001 Runway Asset Prompts

Safety rule for every prompt: support visual only, not actual footage.

## 01 — Opening Pattern Interrupt Card

Prompt: Dark documentary background with subtle bodycam HUD lines, red REC marker blinking, fast push-in on large white text: WATCH THE FINAL MINUTE. Charcoal texture, muted red accents, serious public-record style, no people, no weapons, no gore. Support visual only, not actual footage.

Negative prompt: fake police, fake suspect, fake victim, injury, blood, weapon, reenactment, cartoon, exaggerated sirens.

Duration: 5 seconds  
Aspect ratio: 16:9  
Placement: 00:00 cold open before source footage.

## 02 — Case File Card

Prompt: Close-up of an abstract public-record case file on a dark desk, redacted lines moving across the page, clean white typography area reserved for case title, muted red line accents, realistic paper texture, no names visible. Support visual only, not actual footage.

Duration: 7 seconds  
Aspect ratio: 16:9  
Placement: 00:20 what-we-are-watching section.

## 03 — Timeline Build

Prompt: Minimal dark timeline animation with three evidence markers appearing one by one, clean white labels, muted red timestamp ticks, official documentary style, no people, no crime scene, no reenactment. Support visual only, not actual footage.

Duration: 8 seconds  
Aspect ratio: 16:9  
Placement: 01:10 setup section.

## 04 — The Last 60 Seconds Countdown

Prompt: Cinematic countdown from 60 to 0 on a dark bodycam-inspired interface, red REC dot, subtle scan lines, serious investigative style, no faces, no weapons, no fake police footage. Support visual only, not actual footage.

Duration: 10 seconds  
Aspect ratio: 16:9  
Placement: 08:45 transition into final segment.

## 05 — Final Recap Background

Prompt: Dark charcoal documentary background with faint bodycam grid, slow-moving red timestamp line, clean area for kinetic recap text, official public-record tone, no people, no weapons, no gore. Support visual only, not actual footage.

Duration: 60 seconds  
Aspect ratio: 16:9  
Placement: 09:00 THE LAST 60 SECONDS recap.
