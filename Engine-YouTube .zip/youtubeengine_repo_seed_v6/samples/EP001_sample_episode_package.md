# EP001 Sample Episode Package

This is a fake sample showing what the engine should output. Do not publish this as a real case.

## Machine scorecard

```yaml
episode_id: EP001
case_name: "Late Night Stop Turns Into Search"
source_type: official_release
source_confidence_score: 8.5
copyright_reuse_risk_score: 2
privacy_risk_score: 5
viral_potential_score: 8.1
ten_minute_fit_score: 7.8
final_decision: YELLOW
reason: "Strong bodycam moment and clear escalation, but license plates and bystander faces require blur."
```

## Source summary

The footage appears to show a late-night traffic stop. The officer approaches the vehicle, asks standard questions, and the situation changes when the driver gives an inconsistent answer. Some details remain unclear and must be verified against the source notes.

## Risk review

Must review:

- visible license plate
- possible private address on house/mailbox
- passenger face visible
- unclear final charge/outcome

Recommended action:

- blur plate
- crop house number
- avoid saying “guilty”
- use disclaimer

## Title options

### Mystery titles

1. The Stop Changed In Seconds
2. One Answer Changed Everything
3. Watch His Left Hand
4. The Moment Officers Noticed
5. Something Wasn’t Adding Up
6. The Final Minute Exposed It
7. He Said One Word
8. This Stop Took A Turn
9. The Search Started Here
10. The Footage Gets Quiet

### Bodycam titles

1. Bodycam Shows The Traffic Stop Turning
2. Bodycam Captures The Moment It Changed
3. Police Bodycam Shows The Search
4. Bodycam Footage Reveals The Key Moment
5. Bodycam Shows What Officers Saw

## Thumbnail concepts

1. Text: `WATCH HIS HAND`  
   Visual: driver side window, officer flashlight, red circle near hand  
   Emotion: tension  
   Why: viewer has a specific detail to inspect

2. Text: `ONE WORD`  
   Visual: close frame of officer listening  
   Emotion: curiosity  
   Why: creates mystery without fake claims

3. Text: `STOP CHANGED`  
   Visual: bodycam still with red REC marker  
   Emotion: sudden escalation  
   Why: simple and clickable

## 10-minute structure

```text
00:00–00:20 — Cold Open
The officer freezes after hearing the answer.

00:20–01:10 — What We’re Watching
Explain traffic stop, source, and what remains unknown.

01:10–02:30 — The Setup
Vehicle stopped. Officer asks basic questions.

02:30–04:30 — First Escalation
Driver gives inconsistent answer. Officer asks follow-up.

04:30–06:30 — Key Footage Breakdown
Pause on hand movement, flashlight angle, and officer’s second question.

06:30–07:45 — Turning Point
Officer changes from routine stop to investigation.

07:45–08:45 — Aftermath
Explain known/unknown outcome.

08:45–09:00 — Transition
“Now we go to The Last 60 Seconds.”

09:00–10:00 — THE LAST 60 SECONDS
Recap the three turning points.
```

## Final 60 seconds sample

**THE LAST 60 SECONDS**

In the final minute, three things mattered.

One — the officer asks a simple question, but the answer does not match what is happening on camera.

Two — the driver’s hand movement pulls attention away from the conversation and toward the inside of the vehicle.

Three — the officer changes the tone of the stop. What started as routine becomes a closer look at every detail.

The footage does not answer every question by itself. But it shows the exact moment the stop changed.

That was The Last 60 Seconds.

## YouTube metadata

Recommended title:
**Bodycam Shows The Moment This Stop Changed**

Description:
This episode is based on publicly released footage and available records. Some details may remain under investigation.

Sources:
- [Insert official source URL]

Pinned comment:
What was the first moment you noticed the stop was changing?

Hashtags:
#Bodycam #TrueCrime #PoliceBodycam #PublicRecords #TheLast60Seconds
